import { ManageagentComponent } from './pages/admin/manageagent/manageagent.component';
import { AdminhomeComponent } from './pages/admin/adminhome/adminhome.component';
import { ManagedoctorComponent } from './pages/admin/managedoctor/managedoctor.component';
import { SignupdoctorComponent } from './site/signupdoctor/signupdoctor.component';
import { SignuppatientComponent } from './site/signuppatient/signuppatient.component';
import { SignupadminComponent } from './site/signupadmin/signupadmin.component';
import { LoginComponent } from './login/login.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ManagepatientComponent } from './pages/admin/managepatient/managepatient.component';
import { AddagentComponent } from './pages/admin/manageagent/addagent/addagent.component';
import { ManagemedicareComponent } from './pages/admin/managemedicare/managemedicare.component';


const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'signup-admin', component: SignupadminComponent },
  { path: 'signup-patient', component: SignuppatientComponent },
  { path: 'signup-doctor', component: SignupdoctorComponent },
  { path: 'login', component: LoginComponent },
  { path: 'admin/manage-doctors', component: ManagedoctorComponent },
  { path: 'admin/manage-patients', component: ManagepatientComponent },
  { path: 'admin/manage-agent', component: ManageagentComponent},
  { path: 'admin/manage-agent/add-agent', component: AddagentComponent},
  { path: 'admin/home', component: AdminhomeComponent },
  { path: 'admin/manage-medicare', component: ManagemedicareComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
