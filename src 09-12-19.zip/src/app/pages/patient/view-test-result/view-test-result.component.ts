import { PatientService } from './../../../service/patient.service';
import { MedicaltestService } from './../../../service/medicaltest.service';
import { Component, OnInit } from '@angular/core';
import { DoctorService } from 'src/app/service/doctor.service';
import { Router, ActivatedRoute } from '@angular/router';
import { AppointmentService } from 'src/app/service/appointment.service';
import { LoginServiceService } from 'src/app/service/login-service.service';
import { MedicalTest, DiagTest } from 'src/app/model/medical_test';
import * as jsPDF from 'jspdf';
import 'jspdf-autotable';
import { config } from 'rxjs';

@Component({
  selector: 'app-view-test-result',
  templateUrl: './view-test-result.component.html',
  styleUrls: ['./view-test-result.component.css']
})
export class ViewTestResultComponent implements OnInit {

  appId = '';
  medicalTest: MedicalTest;
  tests: DiagTest[] = [];
  // tslint:disable-next-line: max-line-length
  constructor(private docService: DoctorService, private router: Router, private appointmentService: AppointmentService, private loginservice: LoginServiceService, private medService: MedicaltestService, private patService: PatientService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.paramMap.subscribe((params) => {
      this.appId = params.get('id');
      this.medService.getMedicalTest(this.appId).subscribe((res: MedicalTest) => {
        this.medicalTest = res;
        if (this.medicalTest.diagName1 != '') {
          this.tests.push({
            name: this.medicalTest.diagName1,
            actualValue: this.medicalTest.diagActualValue1,
            normalRange: this.medicalTest.diagNormalRange1
          });
        }
        if (this.medicalTest.diagName2 != '') {
          this.tests.push({
            name: this.medicalTest.diagName2,
            actualValue: this.medicalTest.diagActualValue2,
            normalRange: this.medicalTest.diagNormalRange2
          });
        }
        if (this.medicalTest.diagName3 != '') {
          this.tests.push({
            name: this.medicalTest.diagName3,
            actualValue: this.medicalTest.diagActualValue3,
            normalRange: this.medicalTest.diagNormalRange3
          });
        }
        if (this.medicalTest.diagName4 != '') {
          this.tests.push({
            name: this.medicalTest.diagName4,
            actualValue: this.medicalTest.diagActualValue4,
            normalRange: this.medicalTest.diagNormalRange4
          });
        }
        if (this.medicalTest.diagName5 != '') {
          this.tests.push({
            name: this.medicalTest.diagName5,
            actualValue: this.medicalTest.diagActualValue5,
            normalRange: this.medicalTest.diagNormalRange5
          });

        }
        if (this.medicalTest.diagName6 != '') {
          this.tests.push({
            name: this.medicalTest.diagName6,
            actualValue: this.medicalTest.diagActualValue6,
            normalRange: this.medicalTest.diagNormalRange6
          });
        }









      });



    });
  }

  giveFeedback() {
    this.router.navigateByUrl('/patient/testresults/givefeedback/' + this.medicalTest.reportId)
  }

}
