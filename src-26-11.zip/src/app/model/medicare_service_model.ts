export interface MedicareService{
    medicareServiceId: number;
    medicareServiceName: string;
    medicareServiceDesc: string;
    amount: number;
}