package com.cognizant.clinix.test;

import static org.junit.Assert.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.junit.Assert.*;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.cognizant.clinix.controller.PatientController;
import com.cognizant.clinix.model.Patient;

public class PatientControllerTest {
	PatientController patientController;
	Patient p1 = null;
	Patient p2 = null;

	@Before
	public void setUp() throws Exception {
		patientController = mock(PatientController.class);
		Date date1 = new Date(1997, 07, 03);
		Date date2 = new Date(1998, 06, 04);
		p1 = new Patient(255, "Mitali", "Markande", 22, "female", date1, 852641545, 874564565, "m@gmail.com", "1234",
				"Pune", "pune ", "Pune", "MH", 411030, "What is Your Pet name", "Mitali", false);
		p2 = new Patient(256, "Abhishek", "Sawant", 23, "male", date2, 85266415, 87456465, "a@gmail.com", "12345",
				"Delhi", "delhi", "Pune", "MH", 411020, "What is Your Pet name", "Mm", false);

		
		when(patientController.getAPatients()).thenReturn(Arrays.asList(p1, p2));
		when(patientController.getPatientt(255)).thenReturn(Arrays.asList(p1));
		when(patientController.getPatientt(256)).thenReturn(Arrays.asList(p2));
	}

	@Test
	public final void testGetAllPatients() {
		List<Patient> patients = patientController.getAPatients();
		assertEquals(2, patients.size());
		assertEquals("Mitali", patients.get(0).getFirstName());
	}

	@Test
	public final void testUpdatePatientApproval() {
		Patient p = patientController.getPatientt(255).get(0);
		p.setApprove(true);
		assertEquals(true, p.isApprove());
	}

}
