package com.cognizant.clinix.test;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.*;

import java.sql.Array;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.cognizant.clinix.controller.AgentController;
import com.cognizant.clinix.controller.PatientController;
import com.cognizant.clinix.model.Agent;
import com.cognizant.clinix.model.Patient;

public class AgentControllerTest {

	AgentController agentController;
	Agent a1 = null;
	Agent a2 = null;
	Agent a3 = null;

	@Before
	public void setUp() throws Exception {
		agentController = mock(AgentController.class);
		Date date1 = new Date(1997, 07, 03);
		Date date2 = new Date(1998, 06, 04);
		a1 = new Agent(255, "Mitali", "Markande", 22, "female", date1, 852641545, 874564565, "m@gmail.com", "1234",
				"Pune", "pune ", "Pune", "MH", 411030, 200);
		a2 = new Agent(256, "Abhishek", "Sawant", 23, "male", date2, 85266415, 87456465, "a@gmail.com", "12345",
				"Delhi", "delhi", "Pune", "MH", 411020, 250);
		a3 = new Agent(257, "Abhishekjr", "Sawant", 23, "male", date2, 85266415, 87456465, "a@gmail.com", "12345",
				"Delhi", "delhi", "Pune", "MH", 411020, 250);

		when(agentController.getAAgent()).thenReturn(Arrays.asList(a1, a2));
		when(agentController.getAgentt(255)).thenReturn(Arrays.asList(a1));
		when(agentController.getAgentt(256)).thenReturn(Arrays.asList(a2));
		when(agentController.addNewAgent(a3)).thenReturn(Arrays.asList(a1, a2, a3));
	}

	@Test
	public final void testGetAllAgents() {
		List<Agent> agents = agentController.getAAgent();
		assertEquals(2, agents.size());
		assertEquals("Mitali", agents.get(0).getFirstName());
	}

	@Test
	public final void testAddAgent() {

		List<Agent> agents = agentController.addNewAgent(a3);
		assertEquals(3, agents.size());
	}

	@Test
	public final void testGetAgent() {
		List<Agent> agent1 = agentController.getAgentt(255);
		assertEquals("Mitali", agent1.get(0).getFirstName());

	}

}
