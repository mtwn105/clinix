package com.cognizant.clinix.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.clinix.model.Doctor;
import com.cognizant.clinix.model.MedicalTest;
import com.cognizant.clinix.model.MedicareService;

@Repository
public interface MedicalTestRepository extends JpaRepository<MedicalTest, Long> {
	
	@Query(value = "SELECT report_id,patient_id,doctor_id,agent_id,test_result_date,diag_name_1,diag_name_2,diag_name_3,diag_name_4,diag_name_5,diag_name_6,"
			+ "diag_actual_value_1,diag_actual_value_2,diag_actual_value_3,diag_actual_value_4,diag_actual_value_5,diag_actual_value_6,"
			+ "diag_normal_range_1,diag_normal_range_2,diag_normal_range_3,diag_normal_range_4,diag_normal_range_5,diag_normal_range_6, "
			+ "doctor_comments,other_info,appointment_id from medical_test_history where appointment_id=?", nativeQuery = true)
	MedicalTest viewMedicalTestHistory(String id);
	
}
