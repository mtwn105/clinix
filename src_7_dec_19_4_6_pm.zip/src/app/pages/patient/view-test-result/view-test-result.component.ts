import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-test-result',
  templateUrl: './view-test-result.component.html',
  styleUrls: ['./view-test-result.component.css']
})
export class ViewTestResultComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
