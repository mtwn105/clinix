package com.cognizant.clinix.test;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.cognizant.clinix.controller.DoctorController;
import com.cognizant.clinix.model.Doctor;
import com.cognizant.clinix.model.MedicareService;

public class DoctorControllerTest {
	Doctor d1 = null, d2 = null;
	DoctorController dc;

	@Before
	public void setUp() throws Exception {
		dc = mock(DoctorController.class);

		Date date1 = new Date(1997, 07, 03);
		Date date2 = new Date(1998, 06, 04);

		MedicareService medService1 = new MedicareService(1, "Dentist", "Teeth", 1000);
		MedicareService medService2 = new MedicareService(2, "Neurologist", "Brain", 2000);

		d1 = new Doctor(255, "Mitali", "Markande", "female", date1, "m@gmail.com", "1234", "Pune", "pune ", "Pune",
				"MH", "MBBS", "Dentist", "8-12", "jgvyhjsdfg", false, 411030, "What is Your Pet name", "Mitali", 22,
				852641545, 874564565, medService1);
		d2 = new Doctor(256, "Abhishek", "Sawant", "male", date2, "a@gmail.com", "12345", "Delhi", "delhi", "Pune",
				"MH", "MBBS MD", "Neurologist", "8-12", "jgvyhjjsdfg", false, 411020, "What is Your Pet name", "Mm", 22,
				85266415, 87456465, medService2);

		when(dc.getADoctor()).thenReturn(Arrays.asList(d1, d2));
		when(dc.getDoctor(255)).thenReturn(d1);
		when(dc.getDoctor(256)).thenReturn(d2);

	}

	@Test
	public void testGetDoctors() throws Exception {
		List<Doctor> docs = dc.getADoctor();
		assertEquals(2, docs.size());
		assertEquals(256, dc.getDoctor(256).getDoctorId());
	}

	@Test
	public void testGetDoctor() throws Exception {
		List<Doctor> docs = dc.getADoctor();
		assertEquals(2, docs.size());
	}

	@Test
	public void testUpdateDoctorApproval() throws Exception {
		List<Doctor> docs = dc.getADoctor();
		assertEquals(2, docs.size());

		Doctor d = new Doctor();
		d = dc.getDoctor(255);
		d.setApprove(true);
		assertEquals(true, d.isApprove());

	}

}
