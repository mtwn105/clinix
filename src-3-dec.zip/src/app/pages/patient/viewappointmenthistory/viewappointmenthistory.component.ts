import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewappointmenthistory',
  templateUrl: './viewappointmenthistory.component.html',
  styleUrls: ['./viewappointmenthistory.component.css']
})
export class ViewappointmenthistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
