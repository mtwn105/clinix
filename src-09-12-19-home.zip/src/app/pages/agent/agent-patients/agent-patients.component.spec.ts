import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentPatientsComponent } from './agent-patients.component';

describe('AgentPatientsComponent', () => {
  let component: AgentPatientsComponent;
  let fixture: ComponentFixture<AgentPatientsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentPatientsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentPatientsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
