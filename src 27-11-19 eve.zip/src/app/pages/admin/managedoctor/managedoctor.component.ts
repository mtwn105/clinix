import { MedicareService } from './../../../model/medicare_service_model';
import { DoctorService } from './../../../service/doctor.service';
import { Component, OnInit } from '@angular/core';
import { Doctor } from 'src/app/model/doctor_model';

@Component({
  selector: 'app-managedoctor',
  templateUrl: './managedoctor.component.html',
  styleUrls: ['./managedoctor.component.css']
})
export class ManagedoctorComponent implements OnInit {

  doctors: Doctor[] = [];
  medicareServices: MedicareService[] = [];

  constructor(private doctorService: DoctorService) { }

  ngOnInit() {
    this.doctorService.getAllDoctors().subscribe((res: Doctor[]) => {
      this.doctors = res;
    });
  }

}
