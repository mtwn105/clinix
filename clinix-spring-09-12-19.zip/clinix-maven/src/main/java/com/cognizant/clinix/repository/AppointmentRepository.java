package com.cognizant.clinix.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.clinix.model.Agent;
import com.cognizant.clinix.model.Appointment;
import com.cognizant.clinix.model.Doctor;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Integer> {
	
	@Query(value="SELECT appointment_id,doctor_id,agent_id,time_slot,date_of_appointment,patient_id  FROM appointment WHERE time_slot=? ORDER BY time_slot;",nativeQuery=true)
	List<Appointment> AppointmentsByTimeSlot();
	
	@Query(value="SELECT appointment_id,doctor_id,agent_id,time_slot,date_of_appointment,patient_id  FROM appointment WHERE time_slot=? ORDER BY agent_id DESC;",nativeQuery=true)
	List<Appointment> appointmentsByPriority();
	
	/*@Modifying
	@Transactional
	@Query(value = "Insert into agent(agent_id,first_name,last_name,age,gender,date_of_birth,contact_number,alt_contact_number,email_id,password,address_line_1,address_line_2,city,state,zipcode,commission) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", nativeQuery = true)
	Integer addAgent(long id, String firstName, String lastName, long age, String gender, Date dob, long contact,
			long alt_contact, String email, String password, String address1, String address2, String city, String state, long zipcode, long commission);

   */
	
	@Query(value="SELECT appointment_id,doctor_id,agent_id,time_slot,date_of_appointment,patient_id,status  FROM appointment WHERE appointment_id=?",nativeQuery=true)
	Appointment getAppointment(long id);
	
	@Query(value="SELECT appointment_id,doctor_id,agent_id,time_slot,date_of_appointment,patient_id,status  FROM appointment WHERE patient_id=?;",nativeQuery=true)
	List<Appointment> appointmentsByPatient(long id);

	@Query(value="SELECT appointment_id,doctor_id,agent_id,time_slot,date_of_appointment,patient_id,status  FROM appointment WHERE patient_id=? and date_of_appointment >= NOW();",nativeQuery=true)
	List<Appointment> appointmentsByPatientUpcoming(long id);
	
	@Query(value="SELECT appointment_id,doctor_id,agent_id,time_slot,date_of_appointment,patient_id,status  FROM appointment WHERE patient_id=? and date_of_appointment < NOW() and status='completed'; ",nativeQuery=true)
	List<Appointment> appointmentsByPatientPast(long id);
	

	@Modifying
	@Transactional
	@Query(value="UPDATE appointment SET status=? where appointment_id=?;",nativeQuery=true)
	Integer updateAppointmentApproval(String status, long app_id);
	
	@Query(value="SELECT appointment_id,doctor_id,agent_id,time_slot,date_of_appointment,patient_id,status  FROM appointment WHERE doctor_id=?",nativeQuery=true)
	List<Appointment> appointmentsByDoctor(Doctor doctor);
	@Query(value="SELECT appointment_id,doctor_id,agent_id,time_slot,date_of_appointment,patient_id,status  FROM appointment WHERE doctor_id=? and date_of_appointment > NOW();",nativeQuery=true)
	List<Appointment> appointmentsByDoctorUpcoming(Doctor doctor);
	@Query(value="SELECT appointment_id,doctor_id,agent_id,time_slot,date_of_appointment,patient_id,status  FROM appointment WHERE doctor_id=? and date_of_appointment <= NOW() and status!='completed'; ",nativeQuery=true)
	List<Appointment> appointmentsByDoctorPast(Doctor doctor);
	
	@Query(value="SELECT appointment_id,doctor_id,agent_id,time_slot,date_of_appointment,patient_id,status  FROM appointment WHERE agent_id=?;",nativeQuery=true)
	List<Appointment> appointmentsByAgent(Agent agent);}

	
	

