package com.cognizant.clinix.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.clinix.constants.MedicalTestSQLQueries;
import com.cognizant.clinix.model.MedicalTest;

@Repository
public interface MedicalTestRepository extends JpaRepository<MedicalTest, Long> {
	
	@Query(value = MedicalTestSQLQueries.VIEW_MEDICAL_TEST_HISTORY, nativeQuery = true)
	MedicalTest viewMedicalTestHistory(String id);
	
}
