import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-result-form',
  templateUrl: './test-result-form.component.html',
  styleUrls: ['./test-result-form.component.css']
})
export class TestResultFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }



}
