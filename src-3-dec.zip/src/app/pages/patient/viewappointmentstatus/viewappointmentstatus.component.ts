import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewappointmentstatus',
  templateUrl: './viewappointmentstatus.component.html',
  styleUrls: ['./viewappointmentstatus.component.css']
})
export class ViewappointmentstatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
