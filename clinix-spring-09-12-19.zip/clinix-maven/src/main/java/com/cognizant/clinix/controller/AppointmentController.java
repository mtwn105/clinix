package com.cognizant.clinix.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.clinix.model.Agent;
import com.cognizant.clinix.model.Appointment;
import com.cognizant.clinix.model.Doctor;
import com.cognizant.clinix.service.AppointmentService;

@RestController
@RequestMapping("/appointment")
public class AppointmentController {

	@Autowired
	private AppointmentService appointmentService;
	
	@PostMapping("/add")
	public void addAppointmentRequest(@RequestBody Appointment appointment){
		appointmentService.bookAppointment(appointment);
	}
	
	@GetMapping("/getAll/{id}")
	public List<Appointment> getAllAppointmentsForPatient(@PathVariable long id){
		return appointmentService.appointmentsByPatient(id);
	}
	
	@GetMapping("/getAllUpcoming/{id}")
	public List<Appointment> getAllappointmentsByPatientUpcoming(@PathVariable long id){
		return appointmentService.appointmentsByPatientUpcoming(id);	
	}
	
	@GetMapping("/getAllPast/{id}")
	public List<Appointment> getAllappointmentsByPatientPast(@PathVariable long id){
		return appointmentService.appointmentsByPatientPast(id);	
	}
	
	@PostMapping("/getByDoctor/")
	public List<Appointment> getAllAppointmentsForDoctor(@RequestBody Doctor doc){
		return appointmentService.appointmentByDoctor(doc);
	}
	@PostMapping("/getByDoctorUpcoming/")
	public List<Appointment> getAllAppointmentsForDoctorUpcoming(@RequestBody Doctor doc){
		return appointmentService.getAllAppointmentsForDoctorUpcoming(doc);
	}
	@PostMapping("/getByDoctorPast/")
	public List<Appointment> getAllAppointmentsForDoctorPast(@RequestBody Doctor doc){
		return appointmentService.getAllAppointmentsForDoctorPast(doc);
	}
	
	@PostMapping("/getByAgent/")
	public List<Appointment> getAllAppointmentsForAgent(@RequestBody Agent agent){
		return appointmentService.appointmentByAgent(agent);
	}
	
	@PutMapping("/editApproval")
	 public void updateDoctorApproval(@RequestBody Appointment appointment){
		appointmentService.updateAppointmentApproval(appointment.getStatus(),appointment.getAppointmentId());
	 }
	
	@PostMapping("/getAppointmentId")
	public long getAppointmetId(@RequestBody Appointment appointment){
		return appointmentService.getAppointmetId(appointment);
	}
	
	@GetMapping("/getAppointment/{id}")
	public Appointment getAppointment(@PathVariable long id){
		return appointmentService.getAppointment(id);	
	}
	
	
}
