package com.cognizant.clinix.test;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.cognizant.clinix.controller.MedicareServiceController;
import com.cognizant.clinix.model.MedicareService;

public class MedicareServiceControllerTest {
	MedicareService m1 = null, m2 = null;
	MedicareServiceController ms;

	@Before
	public void setUp() throws Exception {
		ms = mock(MedicareServiceController.class);

		MedicareService m1 = new MedicareService(1, "Dentist", "Teeth", 1000);
		MedicareService m2 = new MedicareService(2, "Neurologist", "Brain", 2000);
		MedicareService m3 = new MedicareService(3, "Cardialogist", "Heart", 1000);

		when(ms.getAMedicareService()).thenReturn(Arrays.asList(m1, m2));
		when(ms.addMedicareService(m3)).thenReturn(m3.getMedicareServiceId());
	}

	@Test
	public void testGetAllMedicareService() throws Exception {
		List<MedicareService> meds = ms.getAMedicareService();
		assertEquals(2, meds.size());

	}

	@Test
	public void testAddMedicareServices() throws Exception {
		MedicareService m3 = new MedicareService(3, "Cardialogist", "Heart", 1000);
		long m = ms.addMedicareService(m3);
		assertNotNull(m);
		assertEquals(m3.getMedicareServiceId(), m);
	}
}
