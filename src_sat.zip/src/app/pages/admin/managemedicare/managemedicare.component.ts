import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managemedicare',
  templateUrl: './managemedicare.component.html',
  styleUrls: ['./managemedicare.component.css']
})
export class ManagemedicareComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
