import { MedicareService } from "./medicare_service_model";
export interface Doctor {
  doctorId: number;
  firstName: string;
  lastName: string;
  gender: string;
  dateOfBirth: Date;
  contactNumber: string;
  altContactNumber: string;
  emailId: string;
  password: string;
  securityQuestion: string;
  securityAnswer: string;
  address1: string;
  address2: string;
  city: string;
  state: string;
  zipcode: number;
  degree: string;
  speciality: string;
  workHours: string;
  hospitalName: string;
  medicareService: MedicareService;
  approve: boolean;
}
