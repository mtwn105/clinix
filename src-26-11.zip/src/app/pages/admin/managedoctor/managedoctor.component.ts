import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managedoctor',
  templateUrl: './managedoctor.component.html',
  styleUrls: ['./managedoctor.component.css']
})
export class ManagedoctorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
