export interface Admin {
  adminId: number;
  firstName: string;
  lastName: string;
  gender: string;
  dateOfBirth: Date;
  contactNumber: string;
  altContactNumber: string;
  emailId: string;
  password: string;
  securityQuestion: string;
  securityAnswer: string;
}
