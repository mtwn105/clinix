export interface MedicareService{
    medicareServiceId: number;
    medicareService: string;
    serviceDescription: string;
    amount: number;
}