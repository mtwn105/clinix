package com.cognizant.clinix.test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.cognizant.clinix.controller.AdminController;
import com.cognizant.clinix.model.Admin;

public class AdminControllerTest {
	Admin a1 = null;
	AdminController ac;

	@Before
	public void setUp() throws Exception {
		ac = mock(AdminController.class);

		Date date1 = new Date(1997, 07, 03);

		a1 = new Admin(100, "Mitali", "Markande", "female", date1, "m@gmail.com", "1234", "What is Your Pet name",
				"Mitali", 22, 852641545, 874564565);

		when(ac.getAAdmin()).thenReturn(Arrays.asList(a1));
		when(ac.getAdmin(100)).thenReturn(a1);

	}

	@Test
	public void getAdmin() throws Exception {
		List<Admin> admin = ac.getAAdmin();
		assertEquals(1, admin.size());
		assertEquals(100, ac.getAdmin(100).getAdminId());
	}

}
