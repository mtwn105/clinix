package com.cognizant.clinix.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.cognizant.clinix.model.Admin;
import com.cognizant.clinix.model.User;
import com.cognizant.clinix.service.AppUser;
import com.cognizant.clinix.service.AppUserDetailService;

@RestController
@RequestMapping("/users")
public class UserController {

	@Autowired
	private AppUserDetailService appUserDetailService;

	@PostMapping("/admin")
	public void signup(@RequestBody Admin admin) {
		try {
			appUserDetailService.signUpAdmin(admin);
		} catch (Exception e) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "User Already Exists");
		}
		/*if (inMemoryUserDetailsManager.userExists(user.getUserName())) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "User Already Exists");
		} else {
			inMemoryUserDetailsManager
					.createUser(org.springframework.security.core.userdetails.User.withUsername(user.getUserName())
							.password(passwordEncoder().encode(user.getPassword())).roles("USER").build());
		}*/
	}
	
	/*@GetMapping()
	public void getAllUsers(){
		Field usersMapField = ReflectionUtils.findField(InMemoryUserDetailsManager.class, "users");
        ReflectionUtils.makeAccessible(usersMapField);
        Map map = (Map)ReflectionUtils.getField(usersMapField, inMemoryUserDetailsManager);
        System.out.println(map);
	}*/
	
	@GetMapping("/{username}")
	public long getUsersId(@PathVariable String username){
	AppUser userDetails =	(AppUser) appUserDetailService.loadUserByUsername(username);
	User user = userDetails.getUser();
	return user.getUserId(); 
	}
	

	public PasswordEncoder passwordEncoder() {
		// LOGGER.info("Start");
		return new BCryptPasswordEncoder();
	}

}
