export interface Medicare{
    medicareServiceId: number;
    medicareService: string;
    serviceDescription: string;
    amount: number;
}