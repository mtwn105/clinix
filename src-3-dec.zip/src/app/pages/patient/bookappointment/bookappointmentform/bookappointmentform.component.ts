import { AgentsService } from './../../../../service/agent.service';
import { Agents } from './../../../../model/agents_model';
import { MedicareService } from './../../../../service/medicare.service';
import { AppointmentService } from './../../../../service/appointment.service';
import { Appointment } from './../../../../model/appointment_model';
import { PatientService } from './../../../../service/patient.service';
import { DoctorService } from './../../../../service/doctor.service';
import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Medicare } from 'src/app/model/medicare_service_model';
import { Doctor } from 'src/app/model/doctor_model';

@Component({
  selector: 'app-bookappointmentform',
  templateUrl: './bookappointmentform.component.html',
  styleUrls: ['./bookappointmentform.component.css']
})
export class BookappointmentformComponent implements OnInit {

  dateOfAppointment = "";
  selectTimeSlot = 0;
  doctor: Doctor;
  medicare: Medicare;
  defaultAgent: Agents;
  doctorId: number;
  medId: number;

  submitted = false;

  bookAppointmentForm: FormGroup;

  // tslint:disable-next-line: max-line-length
  constructor(private formBuilder: FormBuilder, private router: Router, private medicareService: MedicareService, private doctorService: DoctorService, private patientService: PatientService, private appointmentService: AppointmentService, private route: ActivatedRoute, private agentService: AgentsService) { }


  ngOnInit() {
    this.bookAppointmentForm = this.formBuilder.group(
      {
        dateOfAppointment: new FormControl(this.dateOfAppointment, [
          Validators.required
        ]),
        selectTimeSlot: new FormControl(this.selectTimeSlot, [
          Validators.required,
        ]),
      },
    );

    this.route.paramMap.subscribe(params => {

      this.doctorId = +params.get('docId');
      this.medId = +params.get('medId');
      console.log("DOCTOR ID " + this.doctorId)
      console.log("MEDICARE ID " + this.medId)

    });

    this.doctorService.getAllDoctors().subscribe((docs: Doctor[]) => {
      this.doctor = docs.find((doctor: Doctor) => doctor.doctorId === this.doctorId);
      this.medicareService.getAllmedicareService().subscribe((meds: Medicare[]) => {
        this.medicare = meds.find((med: Medicare) => med.medicareServiceId === this.medId);
        this.agentService.getAgent(7235).subscribe((da: Agents
        ) => {
        this.defaultAgent = da; console.log("MEDICARE " + this.medicare.medicareServiceId)
          console.log("AGENT " + this.defaultAgent.agentId)
        });


      });
    });







  }

  get f() { return this.bookAppointmentForm.controls; }


  book() {
    this.submitted = true;
    if (this.bookAppointmentForm.invalid) {
      return;
    }

    console.log(this.bookAppointmentForm.value);

    let appointment: Appointment = {
      dateOfAppointment: this.bookAppointmentForm.value['dateOfAppointment'],
      timeSlot: this.bookAppointmentForm.value['selectTimeSlot'],
      doctor: this.doctor,
      agent: this.defaultAgent,
      status: false
    };

    this.appointmentService.bookWithoutAgent(appointment).subscribe((res) => console.log("SUCCESS"));



    /*  this.appointmentService.bookByAgent(appointment).subscribe(() => {
       console.log('Appointment Booked by Agent');
       alert("Appointment Booked Successfully!!!!");
      // this.router.navigateByUrl('admin/manage-medicare');
     })
   
     this.appointmentService.bookWithoutAgent(appointment).subscribe(() => {
       console.log('Appointment Booked without Agent');
       alert('Appointment Booked Successfully!!!!');
      // this.router.navigateByUrl('admin/manage-medicare');
     }
     ); */
  }


  mustMatch(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
      const control = formGroup.controls[controlName];
      const matchingControl = formGroup.controls[matchingControlName];

      if (matchingControl.errors && !matchingControl.errors.mustMatch) {
        // return if another validator has already found an error on the matchingControl
        return;
      }

      // set error on matchingControl if validation fails
      if (control.value !== matchingControl.value) {
        matchingControl.setErrors({ mustMatch: true });
      } else {
        matchingControl.setErrors(null);
      }
    };
  }

}
